package com.scorekeeper;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.SwitchPreference;

import androidx.annotation.Nullable;

public class SettingsFragment extends PreferenceFragment {

    public static final String saveScoves = "save_scores";
    SharedPreferences sharedpreferences;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.prefs);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final SwitchPreference saveScores = (SwitchPreference) findPreference(this.getResources()
                .getString(R.string.save_scores));
        sharedpreferences = getActivity().getSharedPreferences(MainFragment.MyPREFERENCES, Context.MODE_PRIVATE);

        // SwitchPreference preference change listener
        saveScores.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object o) {
                if (saveScores.isChecked()) {
                    // Checked the switch programmatically
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putBoolean(saveScoves, false);
                    editor.commit();
                    saveScores.setChecked(false);
                } else {
                    // Unchecked the switch programmatically
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putBoolean(saveScoves, true);
                    editor.commit();
                    saveScores.setChecked(true);
                }
                return false;
            }
        });

    }

}
