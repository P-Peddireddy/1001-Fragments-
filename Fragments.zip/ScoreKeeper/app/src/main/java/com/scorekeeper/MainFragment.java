package com.scorekeeper;

import android.app.Fragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MainFragment extends Fragment implements View.OnClickListener {

    public static final String MyPREFERENCES = "MyPrefs";
    public static final String Player1Score = "player1score";
    public static final String Player2Score = "player2score";
    View view;
    float player1_score = 0;
    float player2_score = 0;
    SharedPreferences sharedpreferences;

    Button button1Victory, button1Loss, button1Draw;
    Button button2Victory, button2Loss, button2Draw;
    Button buttonReset;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // retain this fragment
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_main, container, false);

        sharedpreferences = getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        if (sharedpreferences.getBoolean(SettingsFragment.saveScoves, false)) {
            player1_score = sharedpreferences.getFloat(Player1Score, 0);
            displayForPlayer1(player1_score);
            player2_score = sharedpreferences.getFloat(Player2Score, 0);
            displayForPlayer2(player2_score);
        }

        //orientation
        if (savedInstanceState != null) {
            // Restore last state
            player1_score = savedInstanceState.getFloat(Player1Score);
            player2_score = savedInstanceState.getFloat(Player2Score);
            displayForPlayer1(player1_score);
            displayForPlayer2(player2_score);
        } else {
            displayForPlayer1(player1_score);
            displayForPlayer2(player2_score);
        }

        initIds(view);

        return view;

    }

    private void initIds(View view) {

        button1Victory = view.findViewById(R.id.button1Victory);
        button1Draw = view.findViewById(R.id.button1Draw);
        button1Loss = view.findViewById(R.id.button1Loss);
        button2Victory = view.findViewById(R.id.button2Victory);
        button2Draw = view.findViewById(R.id.button2Draw);
        button2Loss = view.findViewById(R.id.button2Loss);
        buttonReset = view.findViewById(R.id.buttonReset);

        button1Victory.setOnClickListener(this);
        button1Draw.setOnClickListener(this);
        button1Loss.setOnClickListener(this);
        button2Victory.setOnClickListener(this);
        button2Draw.setOnClickListener(this);
        button2Loss.setOnClickListener(this);
        buttonReset.setOnClickListener(this);

    }

    private void savePlayerScores() {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putFloat(Player1Score, player1_score);
        editor.putFloat(Player2Score, player2_score);
        editor.commit();
    }


    /**
     * Increase the score for Player 1 by 1 point.
     */
    public void addVictoryForPlayer1(View v) {
        ++player1_score;
        displayForPlayer1(player1_score);
        savePlayerScores();
    }

    /**
     * Don`t increase the score for Player 1.
     */
    public void addLossForPlayer1(View v) {
        if (player1_score > 0)
            --player1_score;
        else
            Toast.makeText(getActivity(), "score cannot be -1", Toast.LENGTH_SHORT).show();

        displayForPlayer1(player1_score);
        savePlayerScores();
    }

    /**
     * Increase the score for Player 1 by 0.5 point.
     */
    public void addDrawForPlayer1(View v) {
        player1_score = (float) (player1_score + 0.5);
        displayForPlayer1(player1_score);
        savePlayerScores();
    }

    /**
     * Increase the score for Player 2 by 1 point.
     */
    public void addVictoryForPlayer2(View v) {
        ++player2_score;
        displayForPlayer2(player2_score);
        savePlayerScores();
    }

    /**
     * Don`t increase the score for Player 2.
     */
    public void addLossForPlayer2(View v) {
        if (player2_score > 0)
            --player2_score;
        else
            Toast.makeText(getActivity(), "score cannot be -1", Toast.LENGTH_SHORT).show();

        displayForPlayer2(player2_score);
        savePlayerScores();
    }

    /**
     * Increase the score for Player 2 by 0.5 point.
     */
    public void addDrawForPlayer2(View v) {
        player2_score = (float) (player2_score + 0.5);
        displayForPlayer2(player2_score);
        savePlayerScores();
    }

    /**
     * Displays the given score for Player 1.
     */
    public void displayForPlayer1(double score) {
        TextView scoreView = (TextView) view.findViewById(R.id.player1_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the given score for Player 2.
     */
    public void displayForPlayer2(double score) {
        TextView scoreView = (TextView) view.findViewById(R.id.player2_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Resets the score for both players back to 0.
     */
    public void ResetScore(View v) {
        player1_score = 0;
        player2_score = 0;
        displayForPlayer1(player1_score);
        displayForPlayer2(player2_score);
        savePlayerScores();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1Victory:
                addVictoryForPlayer1(v);
                break;
            case R.id.button1Draw:
                addDrawForPlayer1(v);
                break;
            case R.id.button1Loss:
                addLossForPlayer1(v);
                break;
            case R.id.button2Victory:
                addVictoryForPlayer2(v);
                break;
            case R.id.button2Draw:
                addDrawForPlayer2(v);
                break;
            case R.id.button2Loss:
                addLossForPlayer2(v);
                break;
            case R.id.buttonReset:
                ResetScore(v);
                break;
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save the state of item position
        outState.putFloat(Player1Score, player1_score);
        outState.putFloat(Player2Score, player2_score);
    }

}
